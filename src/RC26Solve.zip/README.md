# Traditional Project: Rectangle Detection on RC2026

## Overview

This project implements traditional computer vision techniques for white rectangle detection in the RC2026 competition environment.

## Project Structure

### traditional.py
Implements a traditional computer vision method to detect white rectangles.

### traditional2.py
A testing demo for static image rectangle detection.

### traditional2.5.py
Uses Tkinter to dynamically simulate and adjust Canny edge detection thresholds in real-time.

### traditional2.6.py
Beta version serving as a foundation for traditional3.py, with enhanced multi-rectangle tracking capabilities.

### traditional3.py
Detects rectangles in video streams and targets central points. Note: Currently has limitations in multi-rectangle environments.

### test_threshold.py
Provides threshold testing utilities to optimize parameters for Canny edge detection.

### lsd6_video.py

make a point in the central part of the square

### lsd7.py

make a point in the central part of the square and show its position