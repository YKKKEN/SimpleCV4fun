import cv2
import numpy as np
import time

last_detection_time = time.time()
detected_centers = []
tracked_centers = []
max_center_distance = 150

def detect_white_rectangles(frame, frame_num=None):
    global last_detection_time, detected_centers, tracked_centers

    img = frame.copy()
    current_time = time.time()

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (7, 7), 0)

    thresholds = [(1, 30), (30, 60)]

    def has_4_vertices(cnt):
        peri = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
        return len(approx) == 4

    contours = None
    big_contours = []
    for low, high in thresholds:
        edged = cv2.Canny(blurred, low, high)
        edged = cv2.dilate(edged, None, iterations=1)
        contours, _ = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        big_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 70000 and has_4_vertices(cnt)]
        if len(big_contours) > 0:
            break

    rect_count = 0
    current_centers = []

    for cnt in big_contours:
        area = cv2.contourArea(cnt)
        rect = cv2.minAreaRect(cnt)
        center = (int(rect[0][0]), int(rect[0][1]))
        current_centers.append(center)
        rect_count += 1

    if rect_count > 0:
        last_detection_time = current_time
        detected_centers = current_centers

        if len(tracked_centers) == len(current_centers):
            for i, prev_center in enumerate(tracked_centers):
                distances = [np.sqrt((prev_center[0] - c[0])**2 + (prev_center[1] - c[1])**2) for c in current_centers]
                min_idx = distances.index(min(distances))
                tracked_centers[i] = current_centers[min_idx]
                current_centers[min_idx] = None
            current_centers = [c for c in current_centers if c is not None]

        for new_center in current_centers:
            tracked_centers.append(new_center)

        detected_centers = tracked_centers[:rect_count]
    elif current_time - last_detection_time > 2.0:
        detected_centers = []
        tracked_centers = []

    for i, center in enumerate(detected_centers):
        cv2.circle(img, center, 15, (0, 255, 0), -1)
        cv2.putText(img, f"{i+1}:({center[0]}, {center[1]})", (center[0] + 25, center[1] - 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

    cv2.putText(img, f"Count: {rect_count}", (30, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)

    return img, detected_centers

cap = cv2.VideoCapture(r'C:\Users\admin\Documents\GitHub\RC2026\1.mp4')

frame_num = 0
while True:
    ret, frame = cap.read()
    if not ret:
        break
    frame_num += 1
    result, centers = detect_white_rectangles(frame, frame_num)

    cv2.imshow("Video Rectangle Detection", result)

    key = cv2.waitKey(1) & 0xFF
    if key == 27:
        break

cap.release()
cv2.destroyAllWindows()
print(f"共{frame_num}帧")