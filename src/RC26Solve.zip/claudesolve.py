import cv2
import numpy as np


def detect_white_rectangles(image_path, min_area=70000, show_debug=True):
    """
    检测图片中的白色矩形（支持旋转矩形）
    核心策略：
      1. 多阈值 Canny 全跑，候选累积
      2. 矩形度 + 四边形近似 双重验证
      3. 白色区域后置验证
      4. 基于中心距离去重
      5. 可选调试窗口，方便排查
    """
    # 1. 读取图像
    img = cv2.imread(image_path)
    if img is None:
        print(f"无法加载图片: {image_path}")
        return

    h, w = img.shape[:2]

    # --- 预处理 ---
    denoised = cv2.bilateralFilter(img, 9, 75, 75)
    gray = cv2.cvtColor(denoised, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # 色彩空间（用于白色验证）
    hsv = cv2.cvtColor(denoised, cv2.COLOR_BGR2HSV)
    lab = cv2.cvtColor(denoised, cv2.COLOR_BGR2LAB)

    # ============================================================
    # 辅助函数
    # ============================================================

    def is_white_region(cnt):
        """检查轮廓区域整体是否偏白/偏亮"""
        mask = np.zeros(gray.shape, dtype=np.uint8)
        cv2.drawContours(mask, [cnt], -1, 255, -1)
        pixel_count = cv2.countNonZero(mask)
        if pixel_count == 0:
            return False

        mean_v = cv2.mean(hsv[:, :, 2], mask=mask)[0]
        mean_l = cv2.mean(lab[:, :, 0], mask=mask)[0]

        # 白色矩形内部有图案，但整体平均亮度应该 >= 160
        return mean_v >= 160 and mean_l >= 160

    def is_rect_shape(cnt):
        """
        判断轮廓是否为矩形：
          方法A: approxPolyDP 近似到 4 个顶点
          方法B: 矩形度（轮廓面积 / 最小外接矩形面积）> 0.75
        任一通过即可
        """
        area = cv2.contourArea(cnt)
        if area < min_area:
            return False

        rect = cv2.minAreaRect(cnt)
        rect_area = rect[1][0] * rect[1][1]
        if rect_area == 0:
            return False

        # 矩形度：轮廓面积 占 最小外接旋转矩形面积 的比例
        rectangularity = area / rect_area

        # 长宽比：排除细长条
        ww, hh = rect[1]
        if min(ww, hh) == 0:
            return False
        aspect = max(ww, hh) / min(ww, hh)
        if aspect > 4:
            return False

        # 方法A：多 epsilon 尝试近似为四边形
        peri = cv2.arcLength(cnt, True)
        method_a = False
        for eps in [0.02, 0.03, 0.04]:
            approx = cv2.approxPolyDP(cnt, eps * peri, True)
            if len(approx) == 4:
                method_a = True
                break

        # 方法B：矩形度足够高（即使顶点数不是4，形状也够"矩"）
        method_b = (rectangularity > 0.78)

        return method_a or method_b

    # ============================================================
    # 核心检测：多阈值 Canny，全部候选累积
    # ============================================================
    thresholds = [
        (1, 10), (3, 20), (5, 30), (10, 50),
        (20, 80), (30, 100), (50, 150), (80, 200)
    ]

    all_candidates = []  # [(contour, minAreaRect), ...]

    # 用于调试可视化
    debug_edges_combined = np.zeros_like(gray)

    for low, high in thresholds:
        edged = cv2.Canny(blurred, low, high)

        # 闭运算：连接断开的边缘
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        edged = cv2.dilate(edged, kernel, iterations=1)
        edged = cv2.morphologyEx(edged, cv2.MORPH_CLOSE, kernel, iterations=1)

        debug_edges_combined = cv2.bitwise_or(debug_edges_combined, edged)

        # 同时用 RETR_EXTERNAL 和 RETR_TREE
        for mode in [cv2.RETR_EXTERNAL, cv2.RETR_TREE]:
            contours, _ = cv2.findContours(edged, mode, cv2.CHAIN_APPROX_SIMPLE)

            for cnt in contours:
                if not is_rect_shape(cnt):
                    continue
                if not is_white_region(cnt):
                    continue

                rect = cv2.minAreaRect(cnt)
                all_candidates.append((cnt, rect))

    # ============================================================
    # 补充通道：对白色掩膜做形态学 → 直接找轮廓（兜底）
    # ============================================================
    # HSV 白色掩膜
    h_ch, s_ch, v_ch = cv2.split(hsv)
    white_mask = cv2.inRange(hsv, (0, 0, 160), (180, 60, 255))

    # 形态学闭运算填充内部图案造成的孔洞
    kernel_big = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15))
    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_CLOSE, kernel_big, iterations=3)
    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_OPEN, kernel_big, iterations=1)

    contours_mask, _ = cv2.findContours(white_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for cnt in contours_mask:
        if not is_rect_shape(cnt):
            continue
        rect = cv2.minAreaRect(cnt)
        all_candidates.append((cnt, rect))

    # ============================================================
    # 去重
    # ============================================================
    # 按面积从大到小排序，优先保留大的
    all_candidates.sort(key=lambda x: cv2.contourArea(x[0]), reverse=True)

    dedup_dist = min(h, w) * 0.08  # 去重距离阈值

    final_rects = []
    kept_centers = []

    for cnt, rect in all_candidates:
        cx, cy = rect[0]
        area = cv2.contourArea(cnt)

        is_dup = False
        for (ox, oy, oa) in kept_centers:
            dist = np.sqrt((cx - ox) ** 2 + (cy - oy) ** 2)
            if dist < dedup_dist:
                is_dup = True
                break
        if is_dup:
            continue

        final_rects.append((cnt, rect))
        kept_centers.append((cx, cy, area))

    # ============================================================
    # 绘制结果
    # ============================================================
    display_img = img.copy()
    rect_count = len(final_rects)

    for i, (cnt, rect) in enumerate(final_rects):
        box = cv2.boxPoints(rect)
        box = np.intp(box)
        cv2.drawContours(display_img, [box], 0, (0, 255, 0), 3)

        # 标注编号、面积、角度
        center = (int(rect[0][0]), int(rect[0][1]))
        area = int(rect[1][0] * rect[1][1])
        angle = rect[2]
        label = f"#{i + 1} A={area}"
        cv2.putText(display_img, label, (center[0] - 80, center[1] - 15),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)

    # 左上角显示数量
    cv2.putText(display_img, f"Detected: {rect_count}", (30, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)

    print(f"[{image_path}] 检测到 {rect_count} 个白色矩形")

    # --- 显示 ---
    # 缩放显示（大图适配屏幕）
    scale = min(1.0, 1200.0 / w, 800.0 / h)
    disp_w, disp_h = int(w * scale), int(h * scale)

    cv2.imshow("Detection Result", cv2.resize(display_img, (disp_w, disp_h)))

    if show_debug:
        # 调试：拼接 灰度图 | 白色掩膜 | 合并边缘
        debug_gray_3ch = cv2.cvtColor(blurred, cv2.COLOR_GRAY2BGR)
        debug_mask_3ch = cv2.cvtColor(white_mask, cv2.COLOR_GRAY2BGR)
        debug_edge_3ch = cv2.cvtColor(debug_edges_combined, cv2.COLOR_GRAY2BGR)

        debug_img = np.hstack([debug_gray_3ch, debug_mask_3ch, debug_edge_3ch])
        debug_scale = min(1.0, 1800.0 / debug_img.shape[1])
        debug_resized = cv2.resize(debug_img, (int(debug_img.shape[1] * debug_scale),
                                                int(debug_img.shape[0] * debug_scale)))
        cv2.imshow("Debug: Gray | White Mask | Edges", debug_resized)

    cv2.waitKey(0)
    cv2.destroyAllWindows()


# ============ 运行 ============
if __name__ == "__main__":
    paths = [
        r'C:\Users\admin\Documents\GitHub\RC2026\1.png',
        r'C:\Users\admin\Documents\GitHub\RC2026\2.png',
        r'C:\Users\admin\Documents\GitHub\RC2026\3.png',
        r'C:\Users\admin\Documents\GitHub\RC2026\4.png',
        r'C:\Users\admin\Documents\GitHub\RC2026\5.png',
        r'C:\Users\admin\Documents\GitHub\RC2026\6.png',
    ]
    for p in paths:
        detect_white_rectangles(p, min_area=70000, show_debug=True)
