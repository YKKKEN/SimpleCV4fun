import cv2
import numpy as np

def detect_white_rectangles(image_path):
    # 1. 读取图像
    img = cv2.imread(image_path)
    if img is None:
        print("无法加载图片，请检查路径。")
        return

    # --- 预处理模块 (鲁棒性增强) ---
    # 转为灰度图
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 高斯模糊：平滑图像，减少内部图案对边缘检测的干扰
    blurred = cv2.GaussianBlur(gray, (7, 7), 0)

    # 2. Canny 边缘检测 - 多重阈值自适应策略
    # 从极低阈值开始尝试，逐个升高直到找到4边形矩形
    thresholds = [(1, 10), (3, 20), (5, 30), (10, 50), (20, 80), (30, 100), (50, 150), (80, 200)]

    def has_4_vertices(cnt):
        peri = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
        return len(approx) == 4

    contours = None
    for low, high in thresholds:
        edged = cv2.Canny(blurred, low, high)
        edged = cv2.dilate(edged, None, iterations=1)
        contours, _ = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        big_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 70000 and has_4_vertices(cnt)]
        if len(big_contours) > 0:
            break

    rect_count = 0
    display_img = img.copy()

    for cnt in contours:
        # 计算轮廓面积
        area = cv2.contourArea(cnt)
        
        # 矩形面积过滤：必须大于 10000
        if area > 100000:
            # 轮廓近似：判断是否具有 4 个顶点
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)

            # 如果近似为四边形
            if len(approx) == 4:
                # 获取最小外接矩形 (支持旋转)
                # rect 包含: (中心点(x,y), 尺寸(w,h), 旋转角度)
                rect = cv2.minAreaRect(cnt)
                
                # 获取旋转矩形的四个顶点
                box = cv2.boxPoints(rect)
                box = np.intp(box) # 转换为整数坐标

                # 4. 绘制实时框选结果 (绿色框，线宽 3)
                cv2.drawContours(display_img, [box], 0, (0, 255, 0), 3)
                rect_count += 1

    # 5. 在左上角显示检测到的数量
    # 参数：(图像, 文本, 位置, 字体, 缩放, 颜色, 粗细)
    cv2.putText(display_img, f"Count: {rect_count}", (30, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)

    # 6. 显示结果
    cv2.imshow("Rectangle Detection", display_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# 运行路径
file_path = r'C:\Users\admin\Documents\GitHub\RC2026\1.png'
detect_white_rectangles(file_path)

file_path = r'C:\Users\admin\Documents\GitHub\RC2026\2.png'
detect_white_rectangles(file_path)

file_path = r'C:\Users\admin\Documents\GitHub\RC2026\3.png'
detect_white_rectangles(file_path)

file_path = r'C:\Users\admin\Documents\GitHub\RC2026\4.png'
detect_white_rectangles(file_path)


file_path = r'C:\Users\admin\Documents\GitHub\RC2026\5.png'
detect_white_rectangles(file_path)

file_path = r'C:\Users\admin\Documents\GitHub\RC2026\6.png'
detect_white_rectangles(file_path)