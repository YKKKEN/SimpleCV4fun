import cv2
import numpy as np

def detect_squares_lsd(image_path):
    img = cv2.imread(image_path)
    if img is None: return
    
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # LSD 检测线段，不受阈值困扰
    lsd = cv2.createLineSegmentDetector(0)
    lines, _, _, _ = lsd.detect(gray)

    if lines is None: return

    # 1. 过滤短线，保留长线
    min_length = 300 
    valid_lines = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        length = np.sqrt((x2-x1)**2 + (y2-y1)**2)
        if length > min_length:
            valid_lines.append(line[0])

    # 2. 寻找相互垂直且长度相近的线段对
    # 存储可能的正方形中心点
    centers = []

    for i in range(len(valid_lines)):
        for j in range(i + 1, len(valid_lines)):
            l1 = valid_lines[i]
            l2 = valid_lines[j]

            # 计算两条线段的中点
            mid1 = ((l1[0]+l1[2])/2, (l1[1]+l1[3])/2)
            mid2 = ((l2[0]+l2[2])/2, (l2[1]+l2[3])/2)
            
            # 计算向量
            v1 = (l1[2]-l1[0], l1[3]-l1[1])
            v2 = (l2[2]-l2[0], l2[3]-l2[1])
            
            # 计算长度
            len1 = np.sqrt(v1[0]**2 + v1[1]**2)
            len2 = np.sqrt(v2[0]**2 + v2[1]**2)

            # 核心逻辑：如果是正方形的对边或邻边
            # 这里简化为：寻找两条长度相近且距离适中的平行线，或者垂直线
            # 我们通过计算两条线中点的中点作为“疑似中心”
            dist_between_mids = np.sqrt((mid1[0]-mid2[0])**2 + (mid1[1]-mid2[1])**2)
            
            # 如果两条线长度相近，且距离也接近长度（说明可能是对边）
            if 0.8 < len1/len2 < 1.2 and 0.5 < dist_between_mids/len1 < 1.5:
                # 计算这两条线构成的中心
                avg_cx = int((mid1[0] + mid2[0]) / 2)
                avg_cy = int((mid1[1] + mid2[1]) / 2)
                centers.append((avg_cx, avg_cy))

    # 3. 聚类中心点（防止同一正方形有多对线产生多个中心）
    if centers:
        # 简单的去重逻辑：如果点太近，视为同一个
        final_centers = []
        for c in centers:
            is_new = True
            for fc in final_centers:
                if np.sqrt((c[0]-fc[0])**2 + (c[1]-fc[1])**2) < 20:
                    is_new = False
                    break
            if is_new: final_centers.append(c)

        # 4. 绘制中心点
        for (cx, cy) in final_centers:
            cv2.circle(img, (cx, cy), 10, (0, 0, 255), -1)
            cv2.putText(img, "Center", (cx+10, cy), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

    # 绘制检测到的线段供调试
    for l in valid_lines:
        cv2.line(img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 0, 0), 1)

    cv2.imshow("LSD Square Detection", img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

detect_squares_lsd(r'C:\Users\admin\Documents\GitHub\RC2026\1.png')
