import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk

class RectangleDetectionGUI:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("矩形检测 - 参数调节")
        self.window.geometry("1200x800")
        self.window.configure(bg="black")

        self.image = None
        self.display_image = None

        self.canny_low = 30
        self.canny_high = 100
        self.blur_kernel = 7
        self.blur_sigma = 0

        self.cap = None
        self.video_playing = False
        self.current_frame = None

        self.create_widgets()
        self.window.bind("<Configure>", self.on_window_resize)
        self.update_display()

    def create_widgets(self):
        control_frame = tk.Frame(self.window, width=300, bg="#1a1a1a")
        control_frame.pack(side=tk.LEFT, fill=tk.BOTH)

        title_label = tk.Label(control_frame, text="参数调节", font=("Arial", 16, "bold"), bg="#1a1a1a", fg="white")
        title_label.pack(pady=20)

        open_btn = tk.Button(control_frame, text="打开图片", command=self.open_image, width=15, height=2)
        open_btn.pack(pady=10)

        open_video_btn = tk.Button(control_frame, text="打开视频", command=self.open_video, width=15, height=2)
        open_video_btn.pack(pady=10)

        canny_label = tk.Label(control_frame, text="Canny 低阈值", bg="#1a1a1a", fg="white", font=("Arial", 10))
        canny_label.pack(pady=(30, 5))
        self.canny_low_var = tk.DoubleVar(value=self.canny_low)
        canny_low_scale = tk.Scale(control_frame, from_=1, to=200, orient=tk.HORIZONTAL,
                                   variable=self.canny_low_var, command=self.on_param_change,
                                   length=250, bg="#2d2d2d", fg="white", troughcolor="#444444", highlightthickness=0)
        canny_low_scale.pack()

        canny_high_label = tk.Label(control_frame, text="Canny 高阈值", bg="#1a1a1a", fg="white", font=("Arial", 10))
        canny_high_label.pack(pady=(20, 5))
        self.canny_high_var = tk.DoubleVar(value=self.canny_high)
        canny_high_scale = tk.Scale(control_frame, from_=1, to=300, orient=tk.HORIZONTAL,
                                    variable=self.canny_high_var, command=self.on_param_change,
                                    length=250, bg="#2d2d2d", fg="white", troughcolor="#444444", highlightthickness=0)
        canny_high_scale.pack()

        blur_label = tk.Label(control_frame, text="高斯模糊 kernel", bg="#1a1a1a", fg="white", font=("Arial", 10))
        blur_label.pack(pady=(20, 5))
        self.blur_var = tk.IntVar(value=self.blur_kernel)
        blur_scale = tk.Scale(control_frame, from_=1, to=21, orient=tk.HORIZONTAL,
                              variable=self.blur_var, command=self.on_param_change,
                              length=250, bg="#2d2d2d", fg="white", troughcolor="#444444", highlightthickness=0)
        blur_scale.pack()

        blur_sigma_label = tk.Label(control_frame, text="高斯模糊 Sigma", bg="#1a1a1a", fg="white", font=("Arial", 10))
        blur_sigma_label.pack(pady=(20, 5))
        self.blur_sigma_var = tk.IntVar(value=self.blur_sigma)
        blur_sigma_scale = tk.Scale(control_frame, from_=0, to=20, orient=tk.HORIZONTAL,
                                    variable=self.blur_sigma_var, command=self.on_param_change,
                                    length=250, bg="#2d2d2d", fg="white", troughcolor="#444444", highlightthickness=0)
        blur_sigma_scale.pack()

        info_label = tk.Label(control_frame, text="提示: 模糊kernel必须为奇数", bg="#1a1a1a", fg="#888888", font=("Arial", 9))
        info_label.pack(pady=20)

        self.param_label = tk.Label(control_frame, text="", bg="#1a1a1a", fg="yellow", font=("Arial", 10))
        self.param_label.pack(pady=10)

        display_frame = tk.Frame(self.window)
        display_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(display_frame, bg="#1a1a1a")
        self.canvas.pack(fill=tk.BOTH, expand=True)

    def open_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.mp4")])
        if not file_path:
            return

        if file_path.endswith(('.png', '.jpg', '.jpeg', '.bmp')):
            self.image = cv2.imread(file_path)
            self.video_playing = False
            if self.cap:
                self.cap.release()
            self.update_display()
        else:
            self.open_video_file(file_path)

    def open_video(self):
        file_path = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov")])
        if file_path:
            self.open_video_file(file_path)

    def open_video_file(self, file_path):
        self.cap = cv2.VideoCapture(file_path)
        self.video_playing = True
        self.play_video()

    def play_video(self):
        if not self.video_playing or not self.cap:
            return

        ret, frame = self.cap.read()
        if not ret:
            self.cap.release()
            self.video_playing = False
            return

        self.current_frame = frame
        self.update_display()
        self.window.after(30, self.play_video)

    def on_param_change(self, value):
        self.blur_kernel = self.blur_var.get()
        if self.blur_kernel % 2 == 0:
            self.blur_kernel += 1
            self.blur_var.set(self.blur_kernel)

        self.canny_low = int(self.canny_low_var.get())
        self.canny_high = int(self.canny_high_var.get())
        self.blur_sigma = self.blur_sigma_var.get()
        self.update_display()

    def detect_rectangles(self, img):
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        if self.blur_kernel % 2 == 0:
            self.blur_kernel += 1

        blurred = cv2.GaussianBlur(gray, (self.blur_kernel, self.blur_kernel), self.blur_sigma)

        edged = cv2.Canny(blurred, self.canny_low, self.canny_high)
        edged = cv2.dilate(edged, None, iterations=1)

        contours, _ = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        def has_4_vertices(cnt):
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
            return len(approx) == 4

        rect_count = 0
        display_img = img.copy()

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 70000 and has_4_vertices(cnt):
                peri = cv2.arcLength(cnt, True)
                approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
                if len(approx) == 4:
                    rect = cv2.minAreaRect(cnt)
                    box = cv2.boxPoints(rect)
                    box = np.intp(box)
                    cv2.drawContours(display_img, [box], 0, (0, 255, 0), 3)
                    rect_count += 1

        cv2.putText(display_img, f"Count: {rect_count}", (30, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)

        return display_img, rect_count

    def update_display(self):
        if self.image is not None:
            result_img, count = self.detect_rectangles(self.image)
        elif self.current_frame is not None:
            result_img, count = self.detect_rectangles(self.current_frame)
        else:
            result_img = np.zeros((600, 800, 3), dtype=np.uint8)
            cv2.putText(result_img, "请打开图片或视频", (200, 300),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255, 255), 2)

        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()
        if canvas_w > 1 and canvas_h > 1:
            result_img = cv2.resize(result_img, (canvas_w, canvas_h))

        result_img = cv2.cvtColor(result_img, cv2.COLOR_BGR2RGB)

        self.display_image = ImageTk.PhotoImage(Image.fromarray(result_img))
        self.canvas.delete("all")
        self.canvas.create_image(canvas_w // 2, canvas_h // 2, image=self.display_image)

        self.param_label.config(text=f"Canny: {self.canny_low},{self.canny_high} | Blur: {self.blur_kernel},{self.blur_sigma}")

    def on_window_resize(self, event):
        self.update_display()

    def run(self):
        self.window.mainloop()

if __name__ == "__main__":
    gui = RectangleDetectionGUI()
    gui.run()
