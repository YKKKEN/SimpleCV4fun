import cv2
import numpy as np

def detect_white_rectangles(image_path):
    # 1. 读取图像
    img = cv2.imread(image_path)
    if img is None:
        print("无法加载图片，请检查路径。")
        return

    # --- 预处理模块 (鲁棒性增强) ---
    # 转为灰度图
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # 高斯模糊：平滑图像，减少内部图案对边缘检测的干扰
    blurred = cv2.GaussianBlur(gray, (7, 7), 0)
    
    # 形态学闭运算 (Closing)：先膨胀后腐蚀，用于连接被图案断开的白色区域边缘
    kernel = np.ones((5, 5), np.uint8)
    morphed = cv2.morphologyEx(blurred, cv2.MORPH_CLOSE, kernel)
    
    # 2. Canny 边缘检测
    # 阈值可以根据实际光照调节，50-150 是常规白底背景的常用范围
    edged = cv2.Canny(morphed, 50, 150)
    
    # 膨胀边缘：让边缘线条更连续
    edged = cv2.dilate(edged, None, iterations=1)

    # 3. 轮廓提取 (代替基础霍夫变换以获取旋转角度)
    contours, _ = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    rect_count = 0
    display_img = img.copy()

    for cnt in contours:
        # 计算轮廓面积
        area = cv2.contourArea(cnt)
        
        # 矩形面积过滤：必须大于 70000
        if area > 70000:
            # 轮廓近似：判断是否具有 4 个顶点
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)

            # 如果近似为四边形
            if len(approx) == 4:
                # 获取最小外接矩形 (支持旋转)
                # rect 包含: (中心点(x,y), 尺寸(w,h), 旋转角度)
                rect = cv2.minAreaRect(cnt)
                
                # 获取旋转矩形的四个顶点
                box = cv2.boxPoints(rect)
                box = np.intp(box) # 转换为整数坐标

                # 4. 绘制实时框选结果 (绿色框，线宽 3)
                cv2.drawContours(display_img, [box], 0, (0, 255, 0), 3)
                rect_count += 1

    # 5. 在左上角显示检测到的数量
    # 参数：(图像, 文本, 位置, 字体, 缩放, 颜色, 粗细)
    cv2.putText(display_img, f"Count: {rect_count}", (30, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)

    # 6. 显示结果
    cv2.imshow("Rectangle Detection", display_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# 运行路径
file_path = r'C:\Users\admin\Documents\GitHub\RC2026\3.png'
detect_white_rectangles(file_path)
