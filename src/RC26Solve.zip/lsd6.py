import cv2
import numpy as np

def detect_squares_final(image_path):
    img = cv2.imread(image_path)
    if img is None: return
    
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    lsd = cv2.createLineSegmentDetector(0)
    lines, _, _, _ = lsd.detect(gray)
    if lines is None: return

    processed_lines = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        length = np.sqrt((x2-x1)**2 + (y2-y1)**2)
        if length > 200:
            angle = np.arctan2(y2 - y1, x2 - x1)
            mid = np.array([(x1 + x2) / 2, (y1 + y2) / 2])
            processed_lines.append({'line': (x1,y1,x2,y2), 'mid': mid, 'len': length, 'angle': angle})

    raw_centers = []
    for i in range(len(processed_lines)):
        for j in range(i + 1, len(processed_lines)):
            l1, l2 = processed_lines[i], processed_lines[j]
            
            # 1. 严格长度匹配 (差异 < 15%)
            if abs(l1['len'] - l2['len']) / max(l1['len'], l2['len']) > 0.15: continue
            
            # 2. 严格平行匹配 (差异 < 8度)
            angle_diff = abs(l1['angle'] - l2['angle']) % np.pi
            if not (angle_diff < 0.14 or angle_diff > (np.pi - 0.14)): continue

            # 3. 几何投影约束 (解决跨形误报的关键)
            # 计算两条线中点的连线向量
            vec_between = l1['mid'] - l2['mid']
            dist = np.linalg.norm(vec_between)
            
            # 检查距离是否符合正方形比例
            if not (0.8 < dist / l1['len'] < 1.2): continue

            # 重点：中点连线必须几乎垂直于线段本身 (点积接近0)
            # 这确保了这两条边是“面对面”的，而不是错位或者属于两个不同的物体
            vec_line = np.array([np.cos(l1['angle']), np.sin(l1['angle'])])
            dot_product = abs(np.dot(vec_between / dist, vec_line))
            
            if dot_product < 0.2: # 只有当连线与边垂直时，才视为对边
                cx, cy = (l1['mid'] + l2['mid']) / 2
                raw_centers.append((cx, cy))

    # 4. 聚类合并 (NMS)
    final_centers = []
    for pt in raw_centers:
        pt = np.array(pt)
        if not final_centers:
            final_centers.append(pt)
            continue
        if not any(np.linalg.norm(pt - f_pt) < 50 for f_pt in final_centers):
            final_centers.append(pt)

    # 绘制
    for c in final_centers:
        cv2.circle(img, (int(c[0]), int(c[1])), 6, (0, 0, 255), -1)
        cv2.drawMarker(img, (int(c[0]), int(c[1])), (0, 255, 0), cv2.MARKER_CROSS, 12, 2)

    cv2.imshow("No Ghost Centers", img)
    cv2.waitKey(0)

detect_squares_final(r'C:\Users\admin\Documents\GitHub\RC2026\1.png')
