import cv2
import numpy as np

def detect_squares_refined(image_path):
    img = cv2.imread(image_path)
    if img is None: return
    
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    lsd = cv2.createLineSegmentDetector(0)
    lines, _, _, _ = lsd.detect(gray)
    if lines is None: return

    # 1. 预过滤：仅保留足够长的线段，并计算其中点、长度和角度
    processed_lines = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        length = np.sqrt((x2-x1)**2 + (y2-y1)**2)
        if length > 200: # 长度阈值，根据实际正方形大小调整
            angle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
            mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
            processed_lines.append({'line': (x1,y1,x2,y2), 'mid': (mid_x, mid_y), 'len': length, 'angle': angle % 180})

    raw_centers = []
    # 2. 匹配线段对：寻找平行的对边来推导中心
    for i in range(len(processed_lines)):
        for j in range(i + 1, len(processed_lines)):
            l1, l2 = processed_lines[i], processed_lines[j]
            
            # 条件 A: 长度相近 (差异小于 20%)
            if abs(l1['len'] - l2['len']) / max(l1['len'], l2['len']) > 0.2: continue
            
            # 条件 B: 角度接近平行 (差异小于 10 度)
            angle_diff = abs(l1['angle'] - l2['angle'])
            if angle_diff < 10 or angle_diff > 170:
                # 计算两线中点的距离
                dist = np.sqrt((l1['mid'][0]-l2['mid'][0])**2 + (l1['mid'][1]-l2['mid'][1])**2)
                
                # 条件 C: 间距与线段长度接近 (符合正方形对边特征)
                if 0.7 < (dist / l1['len']) < 1.3:
                    cx = (l1['mid'][0] + l2['mid'][0]) / 2
                    cy = (l1['mid'][1] + l2['mid'][1]) / 2
                    raw_centers.append((cx, cy))

    # 3. 聚类：解决多标记点的核心步骤
    final_centers = []
    if raw_centers:
        raw_centers = np.array(raw_centers, dtype=np.float32)
        # 使用简单的距离阈值合并近邻点
        for pt in raw_centers:
            if not final_centers:
                final_centers.append(pt)
                continue
            
            is_duplicate = False
            for f_pt in final_centers:
                if np.linalg.norm(pt - f_pt) < 30: # 30像素内的点合并
                    is_duplicate = True
                    break
            if not is_duplicate:
                final_centers.append(pt)

    # 4. 绘制结果
    for (cx, cy) in final_centers:
        cv2.circle(img, (int(cx), int(cy)), 8, (0, 0, 255), -1)
        cv2.drawMarker(img, (int(cx), int(cy)), (255, 255, 255), cv2.MARKER_CROSS, 15, 2)

    cv2.imshow("Refined Square Centers", img)
    cv2.waitKey(0)

detect_squares_refined(r'C:\Users\admin\Documents\GitHub\RC2026\6.png')
