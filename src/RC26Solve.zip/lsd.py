import cv2
import numpy as np

def detect_squares(image_path):
    img = cv2.imread(image_path)
    if img is None: return
    
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    lsd = cv2.createLineSegmentDetector(0)
    lines, _, _, _ = lsd.detect(gray)

    if lines is None: return

    # 1. 基础过滤：只保留长线段，减少碎线干扰
    min_length = 200
    filtered_lines = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        length = np.sqrt((x2-x1)**2 + (y2-y1)**2)
        if length > min_length:
            filtered_lines.append(line[0])

    # 2. 绘制检测到的长线（验证用）
    line_img = img.copy()
    for l in filtered_lines:
        cv2.line(line_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (0, 255, 0), 2)

    # 3. 这里的关键算法建议：
    # 如果要彻底解决“断续”，可以使用 FastLineDetector 
    # 或者对 filtered_lines 进行简单的“延长线碰撞”逻辑
    
    cv2.imshow("Filtered Long Lines", line_img)
    cv2.waitKey(0)

detect_squares(r'C:\Users\admin\Documents\GitHub\RC2026\1.png')
