import cv2
import numpy as np

def detect_squares_in_frame(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    lsd = cv2.createLineSegmentDetector(0)
    lines, _, _, _ = lsd.detect(gray)
    if lines is None:
        return []

    processed_lines = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        length = np.sqrt((x2-x1)**2 + (y2-y1)**2)
        if length > 200:
            angle = np.arctan2(y2 - y1, x2 - x1)
            mid = np.array([(x1 + x2) / 2, (y1 + y2) / 2])
            processed_lines.append({'line': (x1,y1,x2,y2), 'mid': mid, 'len': length, 'angle': angle})

    raw_centers = []
    for i in range(len(processed_lines)):
        for j in range(i + 1, len(processed_lines)):
            l1, l2 = processed_lines[i], processed_lines[j]

            if abs(l1['len'] - l2['len']) / max(l1['len'], l2['len']) > 0.15:
                continue

            angle_diff = abs(l1['angle'] - l2['angle']) % np.pi
            if not (angle_diff < 0.14 or angle_diff > (np.pi - 0.14)):
                continue

            vec_between = l1['mid'] - l2['mid']
            dist = np.linalg.norm(vec_between)

            if not (0.8 < dist / l1['len'] < 1.2):
                continue

            vec_line = np.array([np.cos(l1['angle']), np.sin(l1['angle'])])
            dot_product = abs(np.dot(vec_between / dist, vec_line))

            if dot_product < 0.2:
                cx, cy = (l1['mid'] + l2['mid']) / 2
                raw_centers.append((cx, cy))

    final_centers = []
    for pt in raw_centers:
        pt = np.array(pt)
        if not final_centers:
            final_centers.append(pt)
            continue
        if not any(np.linalg.norm(pt - f_pt) < 50 for f_pt in final_centers):
            final_centers.append(pt)

    return final_centers

def process_video(video_path):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Cannot open video: {video_path}")
        return

    paused = False

    while True:
        if not paused:
            ret, frame = cap.read()
            if not ret:
                break

        centers = detect_squares_in_frame(frame.copy())

        display = frame.copy()
        for c in centers:
            cv2.circle(display, (int(c[0]), int(c[1])), 6, (0, 0, 255), -1)
            cv2.drawMarker(display, (int(c[0]), int(c[1])), (0, 255, 0), cv2.MARKER_CROSS, 12, 2)

        cv2.imshow("Square Detection", display)

        key = cv2.waitKey(1 if not paused else 0) & 0xFF
        if key == 27:
            break
        elif key == 32:
            paused = not paused

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    process_video(r'C:\Users\admin\Documents\GitHub\RC2026\1.mp4')